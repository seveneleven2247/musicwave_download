const MUSICWAVE_ENDPOINT = "http://127.0.0.1:43828/playback";

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type !== "musicwave-playback" || !message.payload) {
    return;
  }

  updateBadge(message.payload.playing);
  fetch(MUSICWAVE_ENDPOINT, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-MusicWave-Connector": "1"
    },
    body: JSON.stringify(message.payload)
  }).catch(() => {
    updateBadge(false);
  });
});

function updateBadge(isPlaying) {
  chrome.action.setBadgeBackgroundColor({ color: isPlaying ? "#16A34A" : "#6B7280" });
  chrome.action.setBadgeText({ text: isPlaying ? "ON" : "" });
}
