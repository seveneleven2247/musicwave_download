# MusicWave Web Connector

MusicWave Web Connector sends local playback state from supported music websites to the MusicWave desktop app.

Supported websites:

- Spotify Web Player
- YouTube and YouTube Music
- QQ Music Web

The connector sends only the selected website type, playback state, media volume, and page title to `127.0.0.1`. It does not read or transmit passwords, cookies, account details, or browsing history.

## Development installation

1. Open `chrome://extensions` in Chrome or `edge://extensions` in Edge.
2. Enable Developer mode.
3. Choose **Load unpacked** and select this folder.
4. Start MusicWave, enable the desired browser player, and play media on a supported website.

Public distribution requires publishing the packaged extension through the Chrome Web Store and Microsoft Edge Add-ons.
