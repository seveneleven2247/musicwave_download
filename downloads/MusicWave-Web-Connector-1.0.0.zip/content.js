(() => {
  const source = resolveSource(location.hostname);
  if (!source) {
    return;
  }

  const pageId = crypto.randomUUID();
  let lastState = "";
  let reportTimer;

  const report = (force = false) => {
    const state = readPlaybackState();
    const stateKey = JSON.stringify(state);
    if (!force && stateKey === lastState) {
      return;
    }
    lastState = stateKey;

    chrome.runtime.sendMessage({
      type: "musicwave-playback",
      payload: {
        source,
        pageId,
        playing: state.playing,
        volume: state.volume,
        title: state.title
      }
    }).catch(() => {});
  };

  const scheduleReport = () => {
    clearTimeout(reportTimer);
    reportTimer = setTimeout(() => report(true), 120);
  };

  document.addEventListener("play", scheduleReport, true);
  document.addEventListener("pause", scheduleReport, true);
  document.addEventListener("ended", scheduleReport, true);
  document.addEventListener("volumechange", scheduleReport, true);
  document.addEventListener("visibilitychange", scheduleReport, true);

  const observer = new MutationObserver(scheduleReport);
  observer.observe(document.documentElement, {
    attributes: true,
    childList: true,
    subtree: true,
    attributeFilter: ["aria-label", "class", "title"]
  });

  window.addEventListener("pagehide", () => {
    chrome.runtime.sendMessage({
      type: "musicwave-playback",
      payload: {
        source,
        pageId,
        playing: false,
        volume: 0,
        title: document.title
      }
    }).catch(() => {});
  });

  report(true);
  setInterval(() => report(true), 1000);

  function readPlaybackState() {
    const mediaElements = [...document.querySelectorAll("audio, video")]
      .filter((element) => Number.isFinite(element.duration) || element.readyState > 0);
    const playingMedia = mediaElements.find((element) =>
      !element.paused && !element.ended && element.readyState >= 2);
    const selectedMedia = playingMedia || mediaElements[0];

    let playing = Boolean(playingMedia);
    if (source === "spotifyWeb") {
      playing = readSpotifyPlayingState(playing);
    } else if (source === "qqMusicWeb") {
      playing = readQQMusicPlayingState(playing);
    }

    const volume = selectedMedia
      ? (selectedMedia.muted ? 0 : selectedMedia.volume)
      : 1;

    return {
      playing,
      volume: Math.min(Math.max(volume, 0), 1),
      title: cleanTitle(document.title)
    };
  }

  function readSpotifyPlayingState(fallback) {
    const button = document.querySelector('[data-testid="control-button-playpause"]');
    if (!button) {
      return fallback;
    }
    return labelMeansPlaying(button.getAttribute("aria-label") || button.getAttribute("title"));
  }

  function readQQMusicPlayingState(fallback) {
    const button = document.querySelector(
      '.player__btn_play, .player__btn_pause, .btn_big_play, .btn_big_pause, '
        + '[class*="play_btn"], [class*="pause_btn"], [class*="btn_play"], [class*="btn_pause"]'
    );
    if (!button) {
      return fallback;
    }

    const label = [
      button.getAttribute("aria-label"),
      button.getAttribute("title"),
      button.className
    ].filter(Boolean).join(" ");
    if (/pause|暂停|playing|btn_pause/i.test(label)) {
      return true;
    }
    if (/play|播放|btn_play/i.test(label)) {
      return false;
    }
    return fallback;
  }

  function labelMeansPlaying(label) {
    if (/pause|暂停/i.test(label || "")) {
      return true;
    }
    if (/play|播放/i.test(label || "")) {
      return false;
    }
    return false;
  }

  function cleanTitle(title) {
    return title
      .replace(/\s*[|\-–]\s*Spotify\s*$/i, "")
      .replace(/\s*[|\-–]\s*YouTube\s*$/i, "")
      .replace(/\s*[|\-–]\s*QQ音乐\s*$/i, "")
      .trim();
  }

  function resolveSource(hostname) {
    if (hostname === "open.spotify.com") {
      return "spotifyWeb";
    }
    if (hostname === "www.youtube.com" || hostname === "music.youtube.com") {
      return "youtube";
    }
    if (hostname === "y.qq.com") {
      return "qqMusicWeb";
    }
    return null;
  }
})();
